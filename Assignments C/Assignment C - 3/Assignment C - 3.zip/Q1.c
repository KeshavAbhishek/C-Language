// Write a c program to reverse the array elements.

#include <stdio.h>

int main(){
    int array1[5]={1,2,3,4,5};
    int array2[5]={};
    int temp;

    for(int i = 0; i < 5/2; i++) {
        temp = array1[i];
        array1[i] = array1[5-i-1];
        array1[5-i-1] = temp;
    }

    for (int j = 0; j < 5; j++)
    {
        printf("%d\n", array1[j]);
    }

    return 0;
}