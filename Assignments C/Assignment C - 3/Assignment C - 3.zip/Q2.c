// WAP to store 16 elements in an 1D array and find largest and smallest element in the array.

#include <stdio.h>

int main(){
    int maximum = 0;
    int minimum = 0;

    int array1[16] = {};
    printf("Enter value\n");
    for (int i = 0; i < 16; i++)
    {
        printf(": ");
        scanf("%d", &array1[i]);
    }

    maximum = array1[0];
    minimum = array1[0];

    for (int i = 0; i < 16; i++)
    {
        if(array1[i]>maximum){
            maximum = array1[i];
        }
        if(array1[i]<minimum){
            minimum = array1[i];
        }
    }

    printf("Maximum = %d\nMinimum = %d", maximum, minimum);

    return 0;
}